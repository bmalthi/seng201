package main;

/**
 * Enum to represent the type of item
 */
public enum ItemType {
	CARGO, WEAPON, UPGRADE, REPAIR, WAGES, RESCUE
}