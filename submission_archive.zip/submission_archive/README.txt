# seng201
Island Trader Project for SENG201 S1 2021

Project Owners @bma194, kvn17

Submission files
(1) This readme  - README.txt
(2) Zip of everything  - project.zip
(3) Runnable Jar  - IslandTrader.jar

The project can be run a few ways
1) Run the Jar
  java -jar IslandTrader.jar to run the gui
  java -jar IslandTrader.jar cmd to run the cmd ui
2) Unzip the zip project.zip to a folder & import into Eclipse
  (A) Goto File --Import in Eclipse
  (B) Choose "Projects from Folder or Archive"
  (C) Select the directory corresponding to your unzip'ed project.zip
  (D) CLick finish
  (E) In Eclipse, right click on seng201 in the package explorer and goto run as -->Java Application, choose Main.main if asked
  
  
